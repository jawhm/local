        <ul class="footMenu">
            <li class="menu01"><a href="<?php bloginfo("url") ?>/seminar/">セミナースケジュール</a></li>
          <li class="menu02"><a href="<?php bloginfo("url") ?>/school/">参加語学学校紹介</a></li>
        </ul>
        <ul class="footMenu mgb150">
          <li class="menu03"><a href="<?php bloginfo("url") ?>/faq/">よくある質問</a></li>
          <li class="menu04"><a href="<?php bloginfo("url") ?>/access/">会場までのアクセス</a></li>
        </ul><!-- /.footMenu -->

      	
        <div class="pgTop"><a id="toTop" href="">ページトップヘ</a></div>
      </section><!-- /.footSec -->
      <ul class="footMenu spview">
      	<li class="menu01"><a href="<?php bloginfo("url") ?>/seminar/">セミナースケジュール</a></li>
        <li class="menu02"><a href="<?php bloginfo("url") ?>/school/">参加語学学校紹介</a></li>
        <li class="menu03"><a href="<?php bloginfo("url") ?>/faq/">よくある質問</a></li>
        <li class="menu04"><a href="<?php bloginfo("url") ?>/access/">会場までのアクセス</a></li>
      </ul><!-- /.footMenu -->
      
      <div class="pgTop spview"><a id="toTopSp" class="fadeThis" href="">ページトップヘ</a></div>
               
    </div><!-- warraper --> 
       
    <footer>
    	<a class="btn" href="/"><span>協会本サイトへ</span></a>
      <p>
      	一般社団法人 日本ワーキングホリデー協会（JAWHM）<br>
        Copyright© JAPAN Association for Working Holiday Makers<br>
        All right reserved.
      </p>
      <?php wp_footer() ?>
    </footer> 
  </body>
</html>
