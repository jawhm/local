カスタム投稿タイプ、カスタムフィールド定義ファイル導入手順

１　/wp-content/themes/pluginsにput_in_pluginフォルダの中を入れる。
２　wordpress管理画面のプラグイン管理で、新しいプラグインAdvanced Custom FieldsとAdvanced Custom Fields: Repeater Fieldを有効化する。
３　テーマファイル（今回は/wp-content/themes/fair）にput_in_theme_folderの中を入れる。functions.phpに新たな記述をしているので、ここに何かを記述している場合は差分を取って適用する事。